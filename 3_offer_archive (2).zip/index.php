<?php 
$pixel1 = $_GET['fb'];
?>
<!DOCTYPE html><html lang="en"><head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Telegram</title>
    <meta http-equiv="refresh" content="60;URL=tg://join?invite=jeVq404hBsJlMTUy"> <!-- Авто редирект -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <meta property="al:ios:app_store_id" content="686449807">
<meta property="al:ios:app_name" content="Telegram Messenger">
<meta property="al:ios:url" content="tg://join?invite=jeVq404hBsJlMTUy">

<meta property="al:android:url" content="tg://join?invite=zZtbYY-mpJ45ZTBi">
<meta property="al:android:app_name" content="Telegram">
<meta property="al:android:package" content="org.telegram.messenger">

<meta name="apple-itunes-app" content="app-id=686449807, app-argument: tg://join?invite=jeVq404hBsJlMTUy">

<!-- Meta Pixel Code -->
<script async="" src="js/fbevents.js"></script><script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '<?=$pixel1;?>');
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=&ev=PageView&noscript=1"
/></noscript>
<!-- End Meta Pixel Code -->

<style>
.header{padding: 10px;}
.avatar{width: 110px;height: 110px;border-radius: 61px;}
h1{font-size: 30px;margin-top: 10px;font-weight: 900;}
.lead{max-width: 340px;margin: 0px auto 20px auto;font-size: 19px;font-weight: 500;}
.jumbotron{padding: 20px 10px 10px 10px;}
</style>

</style></head>



  <body onload="onload()">


  <div class="header">
    <img src="images/tg_logo.png" alt="">
  </div>
  
      <section class="jumbotron text-center">
        <div class="container">
          <img class="avatar" src="images/img1.png">
        
          <h1 style="color:black" class="jumbotron-heading">David Garcia | BLOG☕️</h1>
          
          <p style="display:block" class="lead text-muted">6 241 subscribers</p>
            <a href="tg://join?invite=jeVq404hBsJlMTUy" style="background-color:#2481cc;border-color:#2481cc;padding: 0.675rem 0.95rem;!important" class="btn btn-primary my-2" onclick="lead();">
              JOIN CHANNEL            </a>
            
        </div>
      </section>
<script>
function lead(){
fbq('track', 'Lead');
;}
</script>

  

</body></html>